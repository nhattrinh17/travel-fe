import { BookingSuccessSection } from "@/sections/booking/Success";

export default function SuccessBooking(): JSX.Element {
  return <BookingSuccessSection />;
}
