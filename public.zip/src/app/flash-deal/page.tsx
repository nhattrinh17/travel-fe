import { FlashDealSection } from "@/sections/FlashDeal";

export default function FlashDealPage(): JSX.Element {
  return <FlashDealSection />;
}
