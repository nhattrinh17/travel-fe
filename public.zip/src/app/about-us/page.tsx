import { AboutUsSection } from "@/sections/AboutUs";

export default function ContactPage(): JSX.Element {
  return <AboutUsSection />;
}
