import { ContactUsSection } from "@/sections/ContactUs";

export default function ContactPage(): JSX.Element {
  return <ContactUsSection />;
}
