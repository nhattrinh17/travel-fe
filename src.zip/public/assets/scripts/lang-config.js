window.__GOOGLE_TRANSLATION_CONFIG__ = {
  languages: [
    { title: "English", name: "en", positionY: -4 },
    { title: "French", name: "fr", positionY: -30 },
    { title: "Korean", name: "ko", positionY: -151 },
    { title: "Chinese", name: "zh-CN", positionY: -200 },
    { title: "Japanese", name: "ja", positionY: -176 },
    { title: "German", name: "de", positionY: -78 },
  ],
  defaultLanguage: "en",
};
