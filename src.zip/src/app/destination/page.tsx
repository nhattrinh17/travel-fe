import { DestinationCruiseSection } from "@/sections/DestinasionCruise";

export default function PageLuxuryBudgetCruise() {
  return <DestinationCruiseSection />;
}
