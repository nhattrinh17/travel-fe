// export const packetTour = [
//   {
//     id: 1,
//     name: "Tour 1",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 11,
//     slug: "tour-1",
//   },
//   {
//     id: 2,
//     name: "Tour 2",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 12,
//     slug: "tour-2",
//   },
//   {
//     id: 3,
//     name: "Tour 3",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 13,
//     slug: "tour-3",
//   },
//   {
//     id: 4,
//     name: "Tour 4",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 14,
//     slug: "tour-4",
//   },
//   {
//     id: 5,
//     name: "Tour 5",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 15,
//     slug: "tour-5",
//   },
//   {
//     id: 6,
//     name: "Tour 6",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 16,
//     slug: "tour-6",
//   },
//   {
//     id: 7,
//     name: "Tour 7",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 17,
//     slug: "tour-7",
//   },
//   {
//     id: 8,
//     name: "Tour 8",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 18,
//     slug: "tour-8",
//   },
//   {
//     id: 9,
//     name: "Tour 9",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 19,
//     slug: "tour-9",
//   },
//   {
//     id: 10,
//     name: "Tour 10",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 110,
//     slug: "tour-10",
//   },
//   {
//     id: 11,
//     name: "Tour 11",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 111,
//     slug: "tour-11",
//   },
//   {
//     id: 12,
//     name: "Tour 12",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 112,
//     slug: "tour-12",
//   },
//   {
//     id: 13,
//     name: "Tour 13",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 113,
//     slug: "tour-13",
//   },
//   {
//     id: 14,
//     name: "Tour 14",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 114,
//     slug: "tour-14",
//   },
//   {
//     id: 15,
//     name: "Tour 15",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 115,
//     slug: "tour-15",
//   },
//   {
//     id: 16,
//     name: "Tour 16",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 116,
//     slug: "tour-16",
//   },
//   {
//     id: 17,
//     name: "Tour 17",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 117,
//     slug: "tour-17",
//   },
//   {
//     id: 18,
//     name: "Tour 18",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     like: 118,
//     slug: "tour-18",
//   },
// ];

// export const cruises = [
//   {
//     name: "cruises 1",
//     slug: "cruises-1",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     position: [
//       {
//         name: "Ao Ech Area",
//         slug: "ao-ech-area",
//       },
//       {
//         name: "Viet Hai Village",
//         slug: "viet-hai-village",
//       },
//     ],
//   },
//   {
//     name: "cruises 2",
//     slug: "cruises-2",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     position: [
//       {
//         name: "Ao Ech Area",
//         slug: "ao-ech-area",
//       },
//       {
//         name: "Viet Hai Village",
//         slug: "viet-hai-village",
//       },
//     ],
//   },
//   {
//     name: "cruises 3",
//     slug: "cruises-3",
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     position: [
//       {
//         name: "Ao Ech Area",
//         slug: "ao-ech-area",
//       },
//       {
//         name: "Viet Hai Village",
//         slug: "viet-hai-village",
//       },
//       {
//         name: "Ao Ech Area",
//         slug: "ao-ech-area",
//       },
//       {
//         name: "Viet Hai Village",
//         slug: "viet-hai-village",
//       },
//       {
//         name: "Ao Ech Area",
//         slug: "ao-ech-area",
//       },
//       {
//         name: "Viet Hai Village",
//         slug: "viet-hai-village",
//       },
//       {
//         name: "Ao Ech Area",
//         slug: "ao-ech-area",
//       },
//       {
//         name: "Viet Hai Village",
//         slug: "viet-hai-village",
//       },
//       {
//         name: "Ao Ech Area",
//         slug: "ao-ech-area",
//       },
//       {
//         name: "Viet Hai Village",
//         slug: "viet-hai-village",
//       },
//       {
//         name: "Ao Ech Area",
//         slug: "ao-ech-area",
//       },
//       {
//         name: "Viet Hai Village",
//         slug: "viet-hai-village",
//       },
//       {
//         name: "Ao Ech Area",
//         slug: "ao-ech-area",
//       },
//       {
//         name: "Viet Hai Village",
//         slug: "viet-hai-village",
//       },
//     ],
//   },
// ];

// export const topCruise = [
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     accompaniedServices: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     price: 300,
//     styleCruise: "Modern",
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 5,
//     isFlashSale: false,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     accompaniedServices: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     price: 300,
//     styleCruise: "Modern",
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     accompaniedServices: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     price: 300,
//     styleCruise: "Modern",
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     accompaniedServices: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     price: 300,
//     styleCruise: "Modern",
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     accompaniedServices: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     price: 300,
//     styleCruise: "Modern",
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     accompaniedServices: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     price: 300,
//     styleCruise: "Modern",
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     accompaniedServices: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     price: 300,
//     styleCruise: "Modern",
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     accompaniedServices: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     price: 300,
//     styleCruise: "Modern",
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
// ];

// export const luxuryCruise = [
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 4,
//     timeLaunched: 2022,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 4,
//     timeLaunched: 2022,
//     isFlashSale: false,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 4,
//     timeLaunched: 2022,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 4,
//     timeLaunched: 2022,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 4,
//     timeLaunched: 2022,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 4,
//     timeLaunched: 2022,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     totalStar: 4,
//     timeLaunched: 2022,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//   },
// ];

// export const top10DailyTour = [
//   {
//     name: "HaLong Bay Tour",
//     totalStar: 4,
//     timeLaunched: 2022,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//   },
//   {
//     name: "HaLong Bay Tour",
//     totalStar: 4,
//     timeLaunched: 2022,
//     isFlashSale: false,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//   },
//   {
//     name: "HaLong Bay Tour",
//     totalStar: 4,
//     timeLaunched: 2022,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//   },
//   {
//     name: "HaLong Bay Tour",
//     totalStar: 4,
//     timeLaunched: 2022,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//   },
//   {
//     name: "HaLong Bay Tour",
//     totalStar: 4,
//     timeLaunched: 2022,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//   },
//   {
//     name: "HaLong Bay Tour",
//     totalStar: 4,
//     timeLaunched: 2022,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//   },
//   {
//     name: "HaLong Bay Tour",
//     totalStar: 4,
//     timeLaunched: 2022,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//   },
// ];

// export const topTour = [
//   {
//     name: "Hanoi Summer Tour - Van Don - Co To Island 3N2D from Hanoi 2024",
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],

//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Hanoi Summer Tour - Van Don - Co To Island 3N2D from Hanoi 2024 for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Hanoi Summer Tour - Van Don - Co To Island 3N2D from Hanoi 2024",
//     totalStar: 1,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],

//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Hanoi Summer Tour - Van Don - Co To Island 3N2D from Hanoi 2024 for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Hanoi Summer Tour - Van Don - Co To Island 3N2D from Hanoi 2024",
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],

//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Hanoi Summer Tour - Van Don - Co To Island 3N2D from Hanoi 2024 for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Hanoi Summer Tour - Van Don - Co To Island 3N2D from Hanoi 2024",
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],

//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Hanoi Summer Tour - Van Don - Co To Island 3N2D from Hanoi 2024 for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Hanoi Summer Tour - Van Don - Co To Island 3N2D from Hanoi 2024",
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     price: 300,
//     accompaniedServices: [],

//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Hanoi Summer Tour - Van Don - Co To Island 3N2D from Hanoi 2024 for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
// ];

// export const cruiseHome = [
//   {
//     name: "Ambassador Signature Cruise",
//     timeLaunched: 2023,
//     travelerLove: [
//       "Style: Modern Luxurious",
//       " Feature 39 opulent cabins, each with a private balcony and en-suite bathroom",
//       " Ambassador New Menu Launch: Michelin-style À La Carte Dinner and Upgraded Vietnamese Seafood Buffet Lunch",
//       " High-class service with highlights of premium Asian - European cuisine",
//       " Diverse entertainment options on board: live music, spa, squid fishing, …",
//       " Visit unique and famous scenic spots on the bay: Viet Hai Fishing Village, Dark and Bright Cave",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//     ],
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     accompaniedServices: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     price: 300,

//     styleCruise: "Modern",
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     timeLaunched: 2023,
//     travelerLove: [
//       "Style: Modern Luxurious",
//       " Feature 39 opulent cabins, each with a private balcony and en-suite bathroom",
//       " Ambassador New Menu Launch: Michelin-style À La Carte Dinner and Upgraded Vietnamese Seafood Buffet Lunch",
//       " High-class service with highlights of premium Asian - European cuisine",
//       " Diverse entertainment options on board: live music, spa, squid fishing, …",
//       " Visit unique and famous scenic spots on the bay: Viet Hai Fishing Village, Dark and Bright Cave",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//     ],
//     totalStar: 5,
//     isFlashSale: false,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     accompaniedServices: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     price: 300,

//     styleCruise: "Modern",
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     timeLaunched: 2023,
//     travelerLove: [
//       "Style: Modern Luxurious",
//       " Feature 39 opulent cabins, each with a private balcony and en-suite bathroom",
//       " Ambassador New Menu Launch: Michelin-style À La Carte Dinner and Upgraded Vietnamese Seafood Buffet Lunch",
//       " High-class service with highlights of premium Asian - European cuisine",
//       " Diverse entertainment options on board: live music, spa, squid fishing, …",
//       " Visit unique and famous scenic spots on the bay: Viet Hai Fishing Village, Dark and Bright Cave",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//     ],
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     accompaniedServices: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     price: 300,

//     styleCruise: "Modern",
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Ambassador Signature Cruise",
//     timeLaunched: 2023,
//     travelerLove: [
//       "Style: Modern Luxurious",
//       " Feature 39 opulent cabins, each with a private balcony and en-suite bathroom",
//       " Ambassador New Menu Launch: Michelin-style À La Carte Dinner and Upgraded Vietnamese Seafood Buffet Lunch",
//       " High-class service with highlights of premium Asian - European cuisine",
//       " Diverse entertainment options on board: live music, spa, squid fishing, …",
//       " Visit unique and famous scenic spots on the bay: Viet Hai Fishing Village, Dark and Bright Cave",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//     ],
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     isAllMeals: true,
//     accompaniedServices: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     price: 300,

//     styleCruise: "Modern",
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
// ];

// export const destinationNear = [
//   {
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     name: "Cong Dam Area",
//     services: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     location: "Bai Tu Long Bay",
//     content:
//       "Located on the less touristy Bai Tu Long Bay, Cong Dam Area is best known for its majestic and poetic natural beauty of an outdoor geological museum. Visitors will feel overwhelmed by the rock mountains formed from stacked stones in straight lines and the peaceful space of waterscape and surrounding scenery.Coming...",
//   },
//   {
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     name: "Cong Dam Area",
//     services: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     location: "Bai Tu Long Bay",
//     content:
//       "Located on the less touristy Bai Tu Long Bay, Cong Dam Area is best known for its majestic and poetic natural beauty of an outdoor geological museum. Visitors will feel overwhelmed by the rock mountains formed from stacked stones in straight lines and the peaceful space of waterscape and surrounding scenery.Coming...",
//   },
//   {
//     image:
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     name: "Cong Dam Area",
//     services: [
//       {
//         name: "All Meals Include",
//         slug: "allMeals",
//       },
//     ],
//     location: "Bai Tu Long Bay",
//     content:
//       "Located on the less touristy Bai Tu Long Bay, Cong Dam Area is best known for its majestic and poetic natural beauty of an outdoor geological museum. Visitors will feel overwhelmed by the rock mountains formed from stacked stones in straight lines and the peaceful space of waterscape and surrounding scenery.Coming...",
//   },
// ];

// export const tourHome = [
//   {
//     name: "Hanoi Summer Tour - Van Don - Ha long Island 3N2D from Hanoi 2024",
//     timeLaunched: 2023,
//     travelerLove: [
//       "Style: Modern Luxurious",
//       " Feature 39 opulent cabins, each with a private balcony and en-suite bathroom",
//       " Ambassador New Menu Launch: Michelin-style À La Carte Dinner and Upgraded Vietnamese Seafood Buffet Lunch",
//       " High-class service with highlights of premium Asian - European cuisine",
//       " Diverse entertainment options on board: live music, spa, squid fishing, …",
//       " Visit unique and famous scenic spots on the bay: Viet Hai Fishing Village, Dark and Bright Cave",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//     ],
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Hanoi Summer Tour - Van Don - Ha long Island 3N2D from Hanoi 2024",
//     timeLaunched: 2023,
//     travelerLove: [
//       "Style: Modern Luxurious",
//       " Feature 39 opulent cabins, each with a private balcony and en-suite bathroom",
//       " Ambassador New Menu Launch: Michelin-style À La Carte Dinner and Upgraded Vietnamese Seafood Buffet Lunch",
//       " High-class service with highlights of premium Asian - European cuisine",
//       " Diverse entertainment options on board: live music, spa, squid fishing, …",
//       " Visit unique and famous scenic spots on the bay: Viet Hai Fishing Village, Dark and Bright Cave",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//     ],
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
//   {
//     name: "Hanoi Summer Tour - Van Don - Ha long Island 3N2D from Hanoi 2024",
//     timeLaunched: 2023,
//     travelerLove: [
//       "Style: Modern Luxurious",
//       " Feature 39 opulent cabins, each with a private balcony and en-suite bathroom",
//       " Ambassador New Menu Launch: Michelin-style À La Carte Dinner and Upgraded Vietnamese Seafood Buffet Lunch",
//       " High-class service with highlights of premium Asian - European cuisine",
//       " Diverse entertainment options on board: live music, spa, squid fishing, …",
//       " Visit unique and famous scenic spots on the bay: Viet Hai Fishing Village, Dark and Bright Cave",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//       " 5-star overnight cruise in Lan Ha Bay  ",
//     ],
//     totalStar: 5,
//     isFlashSale: true,
//     discount: 22,
//     images: [
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//       "https://storage.googleapis.com/viet-travel-bae44.appspot.com/image/1721624919470-paket1.jpg?GoogleAccessId=firebase-adminsdk-a62cq%40viet-travel-bae44.iam.gserviceaccount.com&Expires=16446992400&Signature=iJwOMEnol%2B8rrfiQAr03fum8MEIBqnJBmDfr2%2Bgd4iu5c3bFeoEgnTTb3zlDRxh8w0dJDg0P%2BvQiwKVk97wP3vypdoBEiBtTO8SZZ%2B%2Bp2JadKCli0sSRHrzePdGIQAfC6yJWiL0%2FcPfqgZfKd%2BJV58EOBQYc6ZAr%2FgLf7T%2B1s3RTN2XxoYhzk8TTvB6C7QeUKd1F107SkfaHiPWV%2B45eJuGOlLEdoSb1W4M5qm2A%2FwCYJWFyR2U3PnoL0e2HjN4lkxtm4hJrzun8y%2FjwHxS4SBrk0U5fXLO%2FRCXzXUJUmi3TIocueW4KzNmzOLEQdmtFCgG5lr9%2BpKzvp7ZrPPjtEA%3D%3D",
//     ],
//     price: 300,
//     accompaniedServices: [],
//     totalRoms: 100,
//     content: `<p class="para-cruise" style="overflow: visible; height: auto;">Step on board the elegant and opulent Ambassador Signature Cruise for an unforgettable journey as you discover Lan Ha Bay's magnificence. With 39 trendy and modern cabins and a capacity for 120 guests, this 5-star floating hotel has everything you need for a feel-at-home journey in the middle of the sea: air conditioning, private balconies, en-suite bathrooms, and bathtubs. Along with first-rate accommodation, Ambassador Signature also offers a premium Asian – European cuisine experience as well as a complete complement of modern facilities, including a luxury spa on board, a piano lounge, and a restaurant &amp; bar.</p>`,
//     specialOffers: [
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//       {
//         name: "COMPLIMENTARY COOKING DEMONSTRATION",
//         content: `<div class="content" style="width: 100%;">The best way to learn about a culture is through its culture. Join us for a cooking class onboard with our chef. You will learn how to prepare the delectable traditional Vietnamese dishes and explore more Vietnamese culinary culture.<br><br><b>Conditions:</b><br>- Applied for all booking.</div>`,
//       },
//     ],
//   },
// ];
